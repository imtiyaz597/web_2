// backend/routes/eventRoutes.js
const express = require('express');
const router = express.Router();
const Event = require('../models/Event');

// Dummy middleware for testing — REMOVE when real auth is added
const verifyToken = (req, res, next) => next();
const verifyAdmin = (req, res, next) => next();


// @route   POST /api/events
// @desc    Create a new event (admin only)
router.post('/', verifyToken, verifyAdmin, async (req, res) => {
  try {
    const newEvent = new Event(req.body);
    await newEvent.save();
    res.status(201).json({ message: 'Event created successfully', event: newEvent });
  } catch (error) {
    res.status(500).json({ message: 'Failed to create event', error });
  }
});

// @route   GET /api/events
// @desc    Get all events
router.get('/', async (req, res) => {
  try {
    const events = await Event.find().sort({ date: 1 });
    res.status(200).json(events);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch events', error });
  }
});

module.exports = router;
